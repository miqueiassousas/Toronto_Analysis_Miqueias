# Toronto_Analysis
This project aims to analyze different locations in Toronto
